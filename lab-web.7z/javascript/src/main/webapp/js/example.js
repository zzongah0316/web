/**
 * example.js
 * 자바스크립 소개
 */

// 자바스크립트에서 문자열은 큰따옴표(""), 작은따옴표('') 모두 사용 가능.
 document.writeln('<h2>외부 JS 파일의 코드를 불러오기</h2>');
 console.log('example.js에서 실행됨.');