package com.itwill.spring3.dto;

import lombok.Data;

@Data
public class PostSearchDto {

    private String type;
    private String keyword;
    
}
